﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VaccineRegistration
{
    public partial class mainForm : Form
    {
        private Boolean loggenIn;

        public mainForm()
        {
            InitializeComponent();
            loggenIn = false;
        }

        public Boolean getLoggenIn()
        {
            return loggenIn;
        }

        public void setLoggenIn(Boolean loggenIn)
        {
            this.loggenIn=loggenIn; ;
        }



        private void TypeOfVaccineToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (loggenIn)
            {
                vaccines v = new vaccines(this);
                v.Show();
                
            }else{
             loginForm login = new loginForm("", this);
                login.Show();
            }
        }

        private void ExitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void ShowRequestsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (loggenIn)
            {
                requests r = new requests(this);
                r.Show();
                 
            }
            else{
                loginForm login = new loginForm("requests", this);
                login.Show();
            }

          

           
        }

        private void ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (loggenIn)
            {
                Appointments app = new Appointments(this);
                app.Show();
                 
            }
            else
            {
                loginForm login = new loginForm("appointments", this);
                login.Show();
            }
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            patientForm patient = new patientForm();
            patient.Show();
        }


    }
}
