﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
 

namespace VaccineRegistration
{
    public partial class requests : Form
    {
        public requests()
        {
            InitializeComponent();
        }

        private mainForm mform = null;
        public requests(mainForm mform)
        {
            this.mform = mform;
            InitializeComponent();

        }

        private void Requests_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'vR_DBDataSet.tbl_patient' table. You can move, or remove it, as needed.
            // TODO: This line of code loads data into the 'vR_DBDataSet.tbl_vaccine' table. You can move, or remove it, as needed.
            // TODO: This line of code loads data into the 'vR_DBDataSet.tbl_patient' table. You can move, or remove it, as needed.

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            SqlConnection conn = myConnection.GetConnection();

            try
            {

                string sqlQuery = " SELECT p.id, p.name,p.age, p.phoneno ,  v.vaccine_type ,thedate,p.accepted FROM dbo.tbl_patient p ,dbo.tbl_vaccine v where p.vaccine_id=v.id " +
                    " and p.thedate >= @val1 and  p.thedate<= @val2 and accepted=@val3 ";
                SqlCommand cmd = new SqlCommand(sqlQuery, conn);
                cmd.Parameters.AddWithValue("@val1", dtpFrom.Value);
                cmd.Parameters.AddWithValue("@val2", dtpTo.Value);
                cmd.Parameters.AddWithValue("@val3", "No");
                SqlDataAdapter sdr = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sdr.Fill(dt);
                dtg_resultRq.DataSource = dt;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                myConnection.Dispose(conn);
            }

        }

        private void AcceptRq_Click(object sender, EventArgs e)
        {
            SqlConnection conn = myConnection.GetConnection();


            Int32 selectedRowCount = dtg_resultRq.Rows.GetRowCount(DataGridViewElementStates.Selected);

            if (selectedRowCount == 0)
            {
                MessageBox.Show("no rows are selected");
                return;
            }

            string cellValue = "";
            try
            {
                string query = "update tbl_patient set accepted='yes',duedate=@val2 where id=@val1";
                SqlCommand cmd = null;

                foreach (var row in dtg_resultRq.SelectedRows)
                {
                    cellValue = Convert.ToString(((DataGridViewRow)row).Cells[0].Value);
                    cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@val2", dtp_duedate.Value);
                    cmd.Parameters.AddWithValue("@val1", cellValue);
                    cmd.ExecuteNonQuery();
                    dtg_resultRq.Refresh();
                    dtg_resultRq.Update();

                }

                MessageBox.Show("rows are accepted..");

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                myConnection.Dispose(conn);
            }
        }

        private void PictureBox1_Click(object sender, EventArgs e)
        {
            if (mform != null)
            {
                mform.Show();
                this.Close();
            }
            else
            {
                mform = new mainForm();
                mform.Show();
                Close();
            }
        }
    }   
}
