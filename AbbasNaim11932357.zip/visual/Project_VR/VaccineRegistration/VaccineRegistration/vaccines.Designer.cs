﻿namespace VaccineRegistration
{
    partial class vaccines
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(vaccines));
            this.label1 = new System.Windows.Forms.Label();
            this.txtVaccineName = new System.Windows.Forms.TextBox();
            this.dtg_vaccines = new System.Windows.Forms.DataGridView();
            this.tblvaccineBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.vaccinesDataSet = new VaccineRegistration.vaccinesDataSet();
            this.tbl_vaccineTableAdapter = new VaccineRegistration.vaccinesDataSetTableAdapters.tbl_vaccineTableAdapter();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dtg_vaccines)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblvaccineBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vaccinesDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(364, 135);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "TYPE OF VACCINE";
            // 
            // txtVaccineName
            // 
            this.txtVaccineName.Location = new System.Drawing.Point(364, 150);
            this.txtVaccineName.Margin = new System.Windows.Forms.Padding(2);
            this.txtVaccineName.Name = "txtVaccineName";
            this.txtVaccineName.Size = new System.Drawing.Size(193, 20);
            this.txtVaccineName.TabIndex = 1;
            // 
            // dtg_vaccines
            // 
            this.dtg_vaccines.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtg_vaccines.Location = new System.Drawing.Point(581, 130);
            this.dtg_vaccines.Margin = new System.Windows.Forms.Padding(2);
            this.dtg_vaccines.Name = "dtg_vaccines";
            this.dtg_vaccines.RowHeadersWidth = 51;
            this.dtg_vaccines.RowTemplate.Height = 24;
            this.dtg_vaccines.Size = new System.Drawing.Size(268, 228);
            this.dtg_vaccines.TabIndex = 3;
            // 
            // tblvaccineBindingSource
            // 
            this.tblvaccineBindingSource.DataMember = "tbl_vaccine";
            this.tblvaccineBindingSource.DataSource = this.vaccinesDataSet;
            // 
            // vaccinesDataSet
            // 
            this.vaccinesDataSet.DataSetName = "vaccinesDataSet";
            this.vaccinesDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tbl_vaccineTableAdapter
            // 
            this.tbl_vaccineTableAdapter.ClearBeforeFill = true;
            // 
            // label2
            // 
            this.label2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label2.Location = new System.Drawing.Point(364, 259);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(193, 30);
            this.label2.TabIndex = 6;
            this.label2.Text = "YOU REMOVE SELECTED ROWS";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::VaccineRegistration.Properties.Resources.ASD;
            this.pictureBox4.Location = new System.Drawing.Point(420, 175);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(75, 66);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 9;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.PictureBox4_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::VaccineRegistration.Properties.Resources.deletee;
            this.pictureBox3.Location = new System.Drawing.Point(420, 292);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(75, 66);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 8;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.PictureBox3_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::VaccineRegistration.Properties.Resources.imagesh;
            this.pictureBox2.Location = new System.Drawing.Point(12, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(66, 64);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 7;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.PictureBox2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(9, 130);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(312, 228);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // vaccines
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(886, 459);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.dtg_vaccines);
            this.Controls.Add(this.txtVaccineName);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "vaccines";
            this.Text = "vaccines";
            this.Load += new System.EventHandler(this.Vaccines_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dtg_vaccines)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblvaccineBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vaccinesDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtVaccineName;
        private System.Windows.Forms.DataGridView dtg_vaccines;
        private System.Windows.Forms.PictureBox pictureBox1;
        private vaccinesDataSet vaccinesDataSet;
        private System.Windows.Forms.BindingSource tblvaccineBindingSource;
        private vaccinesDataSetTableAdapters.tbl_vaccineTableAdapter tbl_vaccineTableAdapter;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
    }
}