﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VaccineRegistration
{
    public partial class patientForm : Form
    {
        public patientForm()
        {
            InitializeComponent();
        }

        private void PatientForm_Load(object sender, EventArgs e)
        {
            fillcmbProduit();

        }

        void fillcmbProduit()
        {
            SqlConnection conn = myConnection.GetConnection();
            DataSet ds = new DataSet();
            try
            {
                
                string query = "select id,vaccine_type from tbl_vaccine";
                SqlDataAdapter  ad = new SqlDataAdapter(query, conn);
                ad.Fill(ds, "Test1");
                cbx_vaccine.DataSource = ds.Tables["Test1"];
                cbx_vaccine.ValueMember = "id";
                cbx_vaccine.DisplayMember = "vaccine_type";
                cbx_vaccine.Text = "";
                


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                myConnection.Dispose(conn);
            }

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            if ( txtAddress.Text.Equals("") ||  Convert.ToInt32( txtAge.Text)==0 || txtName.Equals("") || txtPhone.Text.Equals(""))
            {
                MessageBox.Show("please fill all feilds");
                return;
            }

            if (Convert.ToInt32(txtAge.Text) < 18)
            {
                MessageBox.Show("vaccine for adults only 18+");
                return;

            }


            SqlConnection con = myConnection.GetConnection();
            try
            {

                String query = " insert into tbl_patient(location,age,name,phoneno,gender,vaccine_id,thedate,accepted) values(@val1,@val2,@val3,@val4,@val5,@val6,@val7,@val8)";
                SqlCommand command = new SqlCommand(query, con);
                command.Parameters.AddWithValue("@val1", txtAddress.Text.ToString().Trim());
                command.Parameters.AddWithValue("@val2", txtAge.Text.ToString().Trim());
                command.Parameters.AddWithValue("@val3", txtName.Text.ToString().Trim());
                command.Parameters.AddWithValue("@val4", txtPhone.Text.ToString().Trim());
                command.Parameters.AddWithValue("@val5", cmbGender.SelectedItem.ToString().Trim());
                command.Parameters.AddWithValue("@val6", cbx_vaccine.SelectedValue);
                command.Parameters.AddWithValue("@val7", DateTime.Now);
                command.Parameters.AddWithValue("@val8", "No");
                command.ExecuteNonQuery();
                con.Close();
                
                MessageBox.Show("register is complete");
                Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);

            }
            finally
            {
                myConnection.Dispose(con);
            }
        }

        private void TxtAge_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if(!Char.IsDigit(ch)&& ch != 8 && ch!=46)
            {
                e.Handled = true;
            }
        }

        private void PictureBox2_Click(object sender, EventArgs e)
        {
            Close();
        }
        

    }
}
