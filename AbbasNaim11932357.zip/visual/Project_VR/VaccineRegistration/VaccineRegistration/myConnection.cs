﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.IO;
using System.Configuration;

namespace VaccineRegistration
{
    public class myConnection
    {
        //-- code to get a connection object
        public static SqlConnection GetConnection()
        { 
            string str = ConfigurationManager.ConnectionStrings["MylocalConnection"].ConnectionString;
            SqlConnection con = new SqlConnection(str);
            con.Open();
            return con;
        }

        //-- code to make sure to close connection and dispose the object
        public static void Dispose(SqlConnection con)
        {
            if (con.State == System.Data.ConnectionState.Open)
                con.Close();
            con.Dispose();
        }
    }

}
 
