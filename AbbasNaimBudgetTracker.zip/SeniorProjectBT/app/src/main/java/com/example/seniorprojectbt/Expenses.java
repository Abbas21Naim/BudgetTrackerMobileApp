package com.example.seniorprojectbt;

public class Expenses {

    private int idExpense;
    private int UserId;
    private int ExpAmount;
    private String ExpDesc;
    private String ExpDate;

    public Expenses(int idExpense, int userId, int expAmount, String expDesc, String expDate) {
        this.idExpense = idExpense;
        UserId = userId;
        ExpAmount = expAmount;
        ExpDesc = expDesc;
        ExpDate = expDate;
    }

    @Override
    public String toString() {
        return  "idExpense=" + idExpense +
                ", ExpAmount=" + ExpAmount +
                ", ExpDesc='" + ExpDesc + '\'' +
                ", ExpDate='" + ExpDate + '\'' ;
    }
}
