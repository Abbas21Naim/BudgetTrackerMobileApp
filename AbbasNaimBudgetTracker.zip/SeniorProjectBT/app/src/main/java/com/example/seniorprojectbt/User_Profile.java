package com.example.seniorprojectbt;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;
import org.w3c.dom.Text;

import kotlin.time.TestTimeSource;

public class User_Profile extends AppCompatActivity {
TextView tvUserID, tvUsername;
TextView tvBalance , tvLogout , tvAdd , tvSearch , tvChart , tvProfile;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile);
        tvUserID = (TextView) (findViewById(R.id.tvUserID));
        tvUsername = (TextView) (findViewById(R.id.tvUsername));
        tvProfile = (TextView) (findViewById(R.id.tvProfile));
        tvAdd = (TextView)(findViewById(R.id.tvAdd));
        tvSearch = (TextView)(findViewById(R.id.tvSearch)) ;
        tvBalance = (TextView)(findViewById(R.id.tvBalance));


        Intent i4 = getIntent();
        String Username = i4.getStringExtra("Username");

        RequestQueue queue = Volley.newRequestQueue(this);
        String URL = "https://anaimcsci410.000webhostapp.com/getUser.php?Username=" + Username;
        JsonArrayRequest request = new JsonArrayRequest(URL, new Response.Listener<JSONArray>() {


            @Override
            public void onResponse(JSONArray response) {
                try {
                    JSONObject row = response.getJSONObject(0);
                    int idUser = row.getInt("idUser");
                    String username = row.getString("Username");
                    String password = row.getString("Password");
                    String DOB = row.getString("DOB");

                    Users user = new Users(idUser, username, password, DOB);
                    tvUserID.setText(Integer.toString(user.getIdUser()));
                    tvUsername.setText(user.getUsername());


                } catch (Exception ex) {
                    Toast.makeText(User_Profile.this, "Error", Toast.LENGTH_LONG).show();

                }
            }
        }, null);

        queue.add(request);


        tvProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                RequestQueue queue = Volley.newRequestQueue(User_Profile.this);
                String URL = "https://anaimcsci410.000webhostapp.com/getUser.php?Username=" + Username;
                JsonArrayRequest request = new JsonArrayRequest(URL, new Response.Listener<JSONArray>() {


                    @Override
                    public void onResponse(JSONArray response) {
                        try {
                            JSONObject row = response.getJSONObject(0);
                            int idUser = row.getInt("idUser");
                            String Username = row.getString("Username");
                            String Password = row.getString("Password");
                            String DOB = row.getString("DOB");

                            Users user = new Users(idUser, Username, Password, DOB);
                            Intent Profile2 = new Intent(User_Profile.this, profile.class);
                            Profile2.putExtra("Username", user.getUsername());
                            Profile2.putExtra("Password", user.getPassword());
                            Profile2.putExtra("DateOfBirth", user.getDOB());
                            Profile2.putExtra("Id", user.getIdUser());
                            startActivity(Profile2);


                        } catch (Exception ex) {
                            Toast.makeText(User_Profile.this, "Error", Toast.LENGTH_LONG).show();

                        }
                    }
                }, null);

                queue.add(request);
            }
        });

        tvAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                RequestQueue queue = Volley.newRequestQueue(User_Profile.this);
                String URL = "https://anaimcsci410.000webhostapp.com/getUser.php?Username=" + Username;
                JsonArrayRequest request = new JsonArrayRequest(URL, new Response.Listener<JSONArray>() {


                    @Override
                    public void onResponse(JSONArray response) {
                        try {
                            JSONObject row = response.getJSONObject(0);
                            int idUser = row.getInt("idUser");
                            String Username = row.getString("Username");
                            String Password = row.getString("Password");
                            String DOB = row.getString("DOB");

                            Users user = new Users(idUser, Username, Password, DOB);
                            Intent iAdd = new Intent(User_Profile.this, Add.class);
                            iAdd.putExtra("Id", Integer.toString(user.getIdUser()));
                            startActivity(iAdd);


                        } catch (Exception ex) {
                            Toast.makeText(User_Profile.this, "Error", Toast.LENGTH_LONG).show();

                        }
                    }
                }, null);

                queue.add(request);
            }
        });

        tvSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                RequestQueue queue = Volley.newRequestQueue(User_Profile.this);
                String URL = "https://anaimcsci410.000webhostapp.com/getUser.php?Username=" + Username;
                JsonArrayRequest request = new JsonArrayRequest(URL, new Response.Listener<JSONArray>() {


                    @Override
                    public void onResponse(JSONArray response) {
                        try {
                            JSONObject row = response.getJSONObject(0);
                            int idUser = row.getInt("idUser");
                            String Username = row.getString("Username");
                            String Password = row.getString("Password");
                            String DOB = row.getString("DOB");

                            Users user = new Users(idUser, Username, Password, DOB);
                            Intent Search11 = new Intent(User_Profile.this, search.class);
                            Search11.putExtra("Id", Integer.toString(user.getIdUser()));
                            startActivity(Search11);


                        } catch (Exception ex) {
                            Toast.makeText(User_Profile.this, "Error", Toast.LENGTH_LONG).show();

                        }
                    }
                }, null);

                queue.add(request);
            }
        });

        tvBalance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                RequestQueue queue = Volley.newRequestQueue(User_Profile.this);
                String URL = "https://anaimcsci410.000webhostapp.com/getUser.php?Username=" + Username;
                JsonArrayRequest request = new JsonArrayRequest(URL, new Response.Listener<JSONArray>() {


                    @Override
                    public void onResponse(JSONArray response) {
                        try {
                            JSONObject row = response.getJSONObject(0);
                            int idUser = row.getInt("idUser");
                            String Username = row.getString("Username");
                            String Password = row.getString("Password");
                            String DOB = row.getString("DOB");

                            Users user = new Users(idUser, Username, Password, DOB);
                            Intent B1 = new Intent(User_Profile.this, balance.class);
                            B1.putExtra("Id", Integer.toString(user.getIdUser()));
                            startActivity(B1);


                        } catch (Exception ex) {
                            Toast.makeText(User_Profile.this, "Error", Toast.LENGTH_LONG).show();

                        }
                    }
                }, null);

                queue.add(request);
            }
        });
    }

    public void Logout(View view) {


        new AlertDialog.Builder(this)
                .setIcon(R.drawable.logout)
                .setTitle("Logging Out?")
                .setMessage("Are you sure you want to close this account?")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Intent Logout = new Intent(User_Profile.this , Log_Reg.class);
                        startActivity(Logout);
                        finish();
                    }

                })
                .setNegativeButton("No", null)
                .show();


    }


    public void viewChart(View view) {

        Intent c = new Intent(User_Profile.this , chart.class);
        startActivity(c);


    }



}



