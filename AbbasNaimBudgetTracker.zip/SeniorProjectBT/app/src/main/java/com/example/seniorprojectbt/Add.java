package com.example.seniorprojectbt;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class Add extends AppCompatActivity {
    EditText DateInc, DateExp, DescInc, DescExp, AmountInc, AmountExp;
    TextView Date, Desc, Amount;
    Button Clear, Add;
    ProgressBar pb;
    final Calendar exp_inc= Calendar.getInstance();

    int IdInc = (int)(Math.random()*(100000));
    String IdIncome = Integer.toString(IdInc);

    int IdExp = (int)(Math.random()*(100000));
    String IdExpense = Integer.toString(IdExp);

    @Override
    protected void onCreate(Bundle savedInstanceState) {


        Intent iAdd = getIntent();
        String str = iAdd.getStringExtra("Id");
        int Id = Integer.parseInt(str);



        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);


        Date = (TextView) (findViewById(R.id.Date));
        Desc = (TextView) (findViewById(R.id.Description));
        Amount = (TextView) (findViewById(R.id.Amount));
        DateInc = (EditText) (findViewById(R.id.DateInc));
        DateExp = (EditText) (findViewById(R.id.DateExp));
        DescInc = (EditText) (findViewById(R.id.DescInc));
        DescExp = (EditText) (findViewById(R.id.DescExp));
        AmountInc = (EditText) (findViewById(R.id.AmountInc));
        AmountExp = (EditText) (findViewById(R.id.AmountExp));
        Clear = (Button) (findViewById(R.id.Clear));
        Add = (Button) (findViewById(R.id.btnAdd));
        pb = (ProgressBar)(findViewById(R.id.pb));


        Clear.setVisibility(View.GONE);
        pb.setVisibility(View.GONE);
        Add.setVisibility(View.GONE);
        Date.setVisibility(View.GONE);
        Desc.setVisibility(View.GONE);
        Amount.setVisibility(View.GONE);
        DateInc.setVisibility(View.GONE);
        DateExp.setVisibility(View.GONE);
        DescInc.setVisibility(View.GONE);
        DescExp.setVisibility(View.GONE);
        AmountInc.setVisibility(View.GONE);
        AmountExp.setVisibility(View.GONE);


        DatePickerDialog.OnDateSetListener date =new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int day) {
                exp_inc.set(Calendar.YEAR, year);
                exp_inc.set(Calendar.MONTH,month);
                exp_inc.set(Calendar.DAY_OF_MONTH,day);
                updateLabel();
            }
        };
        DateExp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new DatePickerDialog(Add.this,date,exp_inc.get(Calendar.YEAR),exp_inc.get(Calendar.MONTH),exp_inc.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        DateInc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new DatePickerDialog(Add.this,date,exp_inc.get(Calendar.YEAR),exp_inc.get(Calendar.MONTH),exp_inc.get(Calendar.DAY_OF_MONTH)).show();
            }
        });



        final RequestQueue queue = Volley.newRequestQueue(this);


        Spinner spinner = (Spinner) findViewById(R.id.spinner1);
// Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.Category, R.layout.spinner_color);
// Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(R.layout.spinner_dropdown);
// Apply the adapter to the spinner
        spinner.setAdapter(adapter);


        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                if (i == 0) {
                    Clear.setVisibility(View.GONE);
                    Add.setVisibility(View.GONE);
                    Date.setVisibility(View.GONE);
                    Desc.setVisibility(View.GONE);
                    Amount.setVisibility(View.GONE);
                    DateInc.setVisibility(View.GONE);
                    DateExp.setVisibility(View.GONE);
                    DescInc.setVisibility(View.GONE);
                    DescExp.setVisibility(View.GONE);
                    AmountInc.setVisibility(View.GONE);
                    AmountExp.setVisibility(View.GONE);
                    pb.setVisibility(View.GONE);
                    Toast.makeText(Add.this, "Please select category", Toast.LENGTH_SHORT).show();
                }

                if (i == 1) {
                    AmountExp.setVisibility(View.VISIBLE);
                    DateExp.setVisibility(View.VISIBLE);
                    DescExp.setVisibility(View.VISIBLE);
                    Clear.setVisibility(View.VISIBLE);
                    Add.setVisibility(View.VISIBLE);
                    Date.setVisibility(View.VISIBLE);
                    Desc.setVisibility(View.VISIBLE);
                    Amount.setVisibility(View.VISIBLE);
                    AmountInc.setVisibility(View.GONE);
                    DateInc.setVisibility(View.GONE);
                    DescInc.setVisibility(View.GONE);


                    Add.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            String URL = "https://anaimcsci410.000webhostapp.com/Addexp.php";

                            pb.setVisibility(View.VISIBLE);
                            pb.incrementProgressBy(50);
                            Add.setEnabled(false);

                            StringRequest request =  new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
                                @Override
                                public void onResponse(String response) {
                                    Toast.makeText(Add.this, response, Toast.LENGTH_SHORT).show();
                                    pb.setVisibility(View.INVISIBLE);
                                    Add.setEnabled(true);
                                }
                            }, new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    Toast.makeText(Add.this, error.toString(), Toast.LENGTH_SHORT).show();
                                    pb.setVisibility(View.INVISIBLE);
                                    Add.setEnabled(true);
                                }
                            }) {
                                @Override
                                protected Map<String, String> getParams() throws AuthFailureError {
                                    Map<String, String> params = new HashMap<>();
                                    params.put("ID", str);
                                    params.put("idExp", IdExpense);
                                    params.put("AmountExp", AmountExp.getText().toString());
                                    params.put("DateExp", DateExp.getText().toString());
                                    params.put("DescExp", DescExp.getText().toString());

                                    return params;
                                }

                            };

                            queue.add(request);
                        }

                    });


                    Clear.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                            AmountExp.setText("");
                            AmountExp.clearFocus();
                            DateExp.setText("");
                            DateExp.clearFocus();
                            DescExp.setText("");
                            DescExp.clearFocus();


                        }
                    });


                }
                if (i == 2) {

                    AmountInc.setVisibility(View.VISIBLE);
                    DateInc.setVisibility(View.VISIBLE);
                    DescInc.setVisibility(View.VISIBLE);
                    Clear.setVisibility(View.VISIBLE);
                    Add.setVisibility(View.VISIBLE);
                    Date.setVisibility(View.VISIBLE);
                    Desc.setVisibility(View.VISIBLE);
                    Amount.setVisibility(View.VISIBLE);
                    AmountExp.setVisibility(View.GONE);
                    DateExp.setVisibility(View.GONE);
                    DescExp.setVisibility(View.GONE);

                    Add.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            String URL = "https://anaimcsci410.000webhostapp.com/Addinc.php";

                            pb.setVisibility(View.VISIBLE);
                            pb.incrementProgressBy(50);
                            Add.setEnabled(false);

                            StringRequest request =  new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
                                @Override
                                public void onResponse(String response) {
                                    Toast.makeText(Add.this, response, Toast.LENGTH_SHORT).show();
                                    pb.setVisibility(View.INVISIBLE);
                                    Add.setEnabled(true);
                                }
                            }, new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    Toast.makeText(Add.this, error.toString(), Toast.LENGTH_SHORT).show();
                                    pb.setVisibility(View.INVISIBLE);
                                    Add.setEnabled(true);
                                }
                            }) {
                                @Override
                                protected Map<String, String> getParams() throws AuthFailureError {
                                    Map<String, String> params = new HashMap<>();
                                    params.put("ID", str);
                                    params.put("idInc", IdIncome);
                                    params.put("AmountInc", AmountInc.getText().toString());
                                    params.put("DateInc", DateInc.getText().toString());
                                    params.put("DescInc", DescInc.getText().toString());

                                    return params;
                                }

                            };

                            queue.add(request);
                        }

                    });


                    Clear.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                            AmountInc.setText("");
                            AmountInc.clearFocus();
                            DateInc.setText("");
                            DateInc.clearFocus();
                            DescInc.setText("");
                            DescInc.clearFocus();


                        }
                    });


                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }


    private void updateLabel(){
        String myFormat="yyyy-MM-dd";
        SimpleDateFormat dateFormat=new SimpleDateFormat(myFormat, Locale.US);
        DateExp.setText(dateFormat.format(exp_inc.getTime()));
        DateInc.setText(dateFormat.format(exp_inc.getTime()));
    }
}
