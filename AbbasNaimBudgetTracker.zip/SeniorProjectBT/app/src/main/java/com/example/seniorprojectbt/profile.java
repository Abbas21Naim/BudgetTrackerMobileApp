package com.example.seniorprojectbt;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class profile extends AppCompatActivity {

    final Calendar newDOB= Calendar.getInstance();
    EditText editText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

/*
        Intent Profile = getIntent();
        String oldUsername = Profile.getStringExtra("Username");
        String oldPassword = Profile.getStringExtra("Password");
        String oldDOB = Profile.getStringExtra("DateOfBirth");*/

        Intent Profile2 = getIntent();
        String oldUsername = Profile2.getStringExtra("Username");
        String oldPassword = Profile2.getStringExtra("Password");
        String oldDOB = Profile2.getStringExtra("DateOfBirth");

        final EditText newUsername = findViewById(R.id.etEditUsername);
        final EditText newPassword = findViewById(R.id.etNewPass);
        final EditText confirmPass = findViewById(R.id.etConfirmPass);
        final Button btnUser = findViewById(R.id.btnUser);
        final Button btnPass = findViewById(R.id.btnPass);
        final Button btnDOB = findViewById(R.id.btnDOB);

        editText = findViewById(R.id.etNewDOB);


        final RequestQueue queue = Volley.newRequestQueue(this);

        DatePickerDialog.OnDateSetListener date =new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int day) {
                newDOB.set(Calendar.YEAR, year);
                newDOB.set(Calendar.MONTH,month);
                newDOB.set(Calendar.DAY_OF_MONTH,day);
                updateLabel();
            }
        };
        editText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new DatePickerDialog(profile.this,date,newDOB.get(Calendar.YEAR),newDOB.get(Calendar.MONTH),newDOB.get(Calendar.DAY_OF_MONTH)).show();
            }
        });


        btnUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String URL = "https://anaimcsci410.000webhostapp.com/updateUser.php?oldUsername=" + oldUsername;

                btnUser.setEnabled(false);

                StringRequest request =  new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        if(response.equals("Changes Applied succefully")){

                        Toast.makeText(profile.this, response, Toast.LENGTH_SHORT).show();
                        Intent log = new Intent(profile.this, Log_Reg.class);
                        startActivity(log);
                    } else
                            Toast.makeText(profile.this, response, Toast.LENGTH_SHORT).show();  }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(profile.this, error.toString(), Toast.LENGTH_SHORT).show();
                        btnUser.setEnabled(true);
                    }
                }) {
                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {
                        Map<String, String> params = new HashMap<>();
                        params.put("oldUsername", oldUsername);
                        params.put("newUsername", newUsername.getText().toString());

                        return params;
                    }

                };

                queue.add(request);
            }

        });


        btnPass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String URL = "https://anaimcsci410.000webhostapp.com/updatePassword.php?oldUsername=" + oldUsername;

                btnPass.setEnabled(false);

                StringRequest request =  new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Toast.makeText(profile.this, response, Toast.LENGTH_SHORT).show();
                        btnPass.setEnabled(true);
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(profile.this, error.toString(), Toast.LENGTH_SHORT).show();
                        btnPass.setEnabled(true);
                    }
                }) {
                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {
                        Map<String, String> params = new HashMap<>();
                        params.put("oldUsername", oldUsername);
                        params.put("newPassword", newPassword.getText().toString());
                        params.put("confirmPass", confirmPass.getText().toString());

                        return params;
                    }

                };

                queue.add(request);
            }

        });


        btnDOB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String URL = "https://anaimcsci410.000webhostapp.com/updateDOB.php?oldUsername=" + oldUsername;

                btnDOB.setEnabled(false);

                StringRequest request =  new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Toast.makeText(profile.this, response, Toast.LENGTH_SHORT).show();
                        btnDOB.setEnabled(true);
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(profile.this, error.toString(), Toast.LENGTH_LONG).show();
                        btnDOB.setEnabled(true);
                    }
                }) {
                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {
                        Map<String, String> params = new HashMap<>();
                        params.put("oldUsername", oldUsername);
                        params.put("newDOB", editText.getText().toString());

                        return params;
                    }

                };

                queue.add(request);
            }

        });

    }

    private void updateLabel(){
        String myFormat="yyyy-MM-dd";
        SimpleDateFormat dateFormat=new SimpleDateFormat(myFormat, Locale.US);
        editText.setText(dateFormat.format(newDOB.getTime()));
    }

}