package com.example.seniorprojectbt;

public class Users {

    private int idUser;
    private String Username;
    private String Password;
    private String DOB;

    public Users(int idUser, String Username, String Password, String DOB) {
        this.idUser = idUser;
        this.Username = Username;
        this.Password = Password;
        this.DOB = DOB;
    }

    public int getIdUser() {
        return idUser;
    }

    public String getUsername() {
        return Username;
    }

    public String getPassword() {
        return Password;
    }

    public String getDOB() {
        return DOB;
    }

    @Override
    public String toString() {
        return "Users:" +
                "idUser:" + idUser +
                ", Username:'" + Username + '\'' +
                ", Password:'" + Password + '\'' +
                ", DOB:'" + DOB + '\'' +
                '}';
    }
}
