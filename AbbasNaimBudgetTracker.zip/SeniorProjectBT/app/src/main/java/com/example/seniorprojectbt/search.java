package com.example.seniorprojectbt;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class search extends AppCompatActivity {

    Button Clear, Search;
    EditText etDateExp , etDateInc;
    TextView tvDateTitle;
    ListView lvResult;
    ProgressBar pb;
    final Calendar exp_inc= Calendar.getInstance();



    @Override
    protected void onCreate(Bundle savedInstanceState) {

        Intent Search11 = getIntent();
        String str = Search11.getStringExtra("Id");

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);


        Clear = (Button) (findViewById(R.id.btnClear));
        Clear.setVisibility(View.GONE);
        Search = (Button) (findViewById(R.id.btnSearch));
        Search.setVisibility(View.GONE);
        etDateExp = (EditText) (findViewById(R.id.etDateExp));
        etDateInc = (EditText) (findViewById(R.id.etDateInc));
        etDateExp.setVisibility(View.GONE);
        etDateInc.setVisibility(View.GONE);
        tvDateTitle = (TextView) (findViewById(R.id.tvDateTitle));
        tvDateTitle.setVisibility(View.GONE);
        lvResult = (ListView) (findViewById(R.id.ListViewResult));
        lvResult.setVisibility(View.GONE);
        pb = (ProgressBar) (findViewById(R.id.pb));
        pb.setVisibility(View.GONE);


        DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int day) {
                exp_inc.set(Calendar.YEAR, year);
                exp_inc.set(Calendar.MONTH, month);
                exp_inc.set(Calendar.DAY_OF_MONTH, day);
                updateLabel();
            }
        };
        etDateExp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new DatePickerDialog(search.this, date, exp_inc.get(Calendar.YEAR), exp_inc.get(Calendar.MONTH), exp_inc.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        etDateInc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new DatePickerDialog(search.this, date, exp_inc.get(Calendar.YEAR), exp_inc.get(Calendar.MONTH), exp_inc.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        final RequestQueue queue = Volley.newRequestQueue(this);
        final RequestQueue queue1 = Volley.newRequestQueue(this);


        Spinner spinner = (Spinner) findViewById(R.id.spinner2);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.Category, R.layout.spinner_color);
        adapter.setDropDownViewResource(R.layout.spinner_dropdown);

        spinner.setAdapter(adapter);


        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                if (i == 0) {
                    Clear.setVisibility(View.GONE);
                    Search.setVisibility(View.GONE);
                    etDateExp.setVisibility(View.GONE);
                    etDateInc.setVisibility(View.GONE);
                    tvDateTitle.setVisibility(View.GONE);
                    lvResult.setVisibility(View.GONE);
                    pb.setVisibility(View.GONE);
                    Toast.makeText(search.this, "Please Select a Category", Toast.LENGTH_LONG).show();

                }
                if (i == 1) {

                    Clear.setVisibility(View.VISIBLE);
                    Search.setVisibility(View.VISIBLE);
                    etDateExp.setVisibility(View.VISIBLE);
                    etDateInc.setVisibility(View.GONE);
                    tvDateTitle.setVisibility(View.VISIBLE);
                    lvResult.setVisibility(View.GONE);
                    pb.setVisibility(View.GONE);

                    Search.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {


                            pb.setVisibility(View.VISIBLE);
                            pb.incrementProgressBy(50);


                            String URL = "https://anaimcsci410.000webhostapp.com/SearchExp.php?DateExp=" + etDateExp.getText() + "&idUser=" + str;
                            ArrayList<Expenses> expenses = new ArrayList<>();

                            RequestQueue queue = Volley.newRequestQueue(search.this);

                            JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(URL, new Response.Listener<JSONArray>() {
                                @Override
                                public void onResponse(JSONArray response) {

                                    try {
                                        for (int i = 0; i < response.length(); i++) {
                                            JSONObject rows = response.getJSONObject(i);
                                            int idExp = rows.getInt("idExpense");
                                            int UserId = rows.getInt("UserId");
                                            int AmountExp = rows.getInt("ExpAmount");
                                            String DescExp = rows.getString("ExpDesc");
                                            String DateExp = rows.getString("ExpDate");

                                            Expenses E = new Expenses(idExp, UserId, AmountExp, DescExp, DateExp);
                                            expenses.add(E);


                                        }
                                        pb.setVisibility(View.INVISIBLE);
                                        lvResult.setVisibility(View.VISIBLE);
                                        lvResult.setAdapter(new ArrayAdapter<Expenses>(search.this, android.R.layout.simple_list_item_1, expenses));
                                        pb.setVisibility(View.INVISIBLE);
                                    } catch (JSONException error) {
                                        Toast.makeText(search.this, error.toString(), Toast.LENGTH_SHORT).show();

                                    }
                                }
                            }, new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    Toast.makeText(search.this, "Error006: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            });

                            queue.add(jsonArrayRequest);
                        }
                    });

                    Clear.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                            etDateExp.setText("");
                            etDateExp.clearFocus();
                            lvResult.clearFocus();
                            lvResult.setVisibility(View.GONE);
                            pb.setVisibility(View.GONE);


                        }
                    });
                }

                if (i == 2) {

                    Clear.setVisibility(View.VISIBLE);
                    Search.setVisibility(View.VISIBLE);
                    etDateExp.setVisibility(View.GONE);
                    etDateInc.setVisibility(View.VISIBLE);
                    tvDateTitle.setVisibility(View.VISIBLE);
                    lvResult.setVisibility(View.GONE);
                    pb.setVisibility(View.GONE);

                    Search.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {


                            pb.setVisibility(View.VISIBLE);
                            pb.incrementProgressBy(50);


                            String URL = "https://anaimcsci410.000webhostapp.com/SearchInc.php?DateInc=" + etDateInc.getText() + "&idUser=" + str;
                            ArrayList<Incomes> incomes = new ArrayList<>();

                            RequestQueue queue = Volley.newRequestQueue(search.this);

                            JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(URL, new Response.Listener<JSONArray>() {
                                @Override
                                public void onResponse(JSONArray response) {

                                    try {
                                        for (int i = 0; i < response.length(); i++) {
                                            JSONObject rows = response.getJSONObject(i);
                                            int idInc = rows.getInt("idIncome");
                                            int UserId = rows.getInt("UserId");
                                            int AmountInc = rows.getInt("IncAmount");
                                            String DescInc = rows.getString("IncDesc");
                                            String DateInc = rows.getString("IncDate");

                                            Incomes I = new Incomes(idInc, UserId, AmountInc, DescInc, DateInc);
                                            incomes.add(I);


                                        }
                                        pb.setVisibility(View.INVISIBLE);
                                        lvResult.setVisibility(View.VISIBLE);
                                        lvResult.setAdapter(new ArrayAdapter<Incomes>(search.this, android.R.layout.simple_list_item_1, incomes));
                                        pb.setVisibility(View.INVISIBLE);
                                    } catch (JSONException error) {
                                        Toast.makeText(search.this, error.toString(), Toast.LENGTH_SHORT).show();

                                    }
                                }
                            }, new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    Toast.makeText(search.this, "Error006: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            });
                            queue.add(jsonArrayRequest);
                        }
                    });

                    Clear.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                            etDateExp.setText("");
                            etDateExp.clearFocus();
                            lvResult.clearFocus();
                            lvResult.setVisibility(View.GONE);
                            pb.setVisibility(View.GONE);


                        }
                    });
                }
            }


            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    private void updateLabel(){
        String myFormat="yyyy-MM-dd";
        SimpleDateFormat dateFormat=new SimpleDateFormat(myFormat, Locale.US);
        etDateExp.setText(dateFormat.format(exp_inc.getTime()));
        etDateInc.setText(dateFormat.format(exp_inc.getTime()));
    }
}
