package com.example.seniorprojectbt;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.AlertDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

public class Admin_Profile extends AppCompatActivity {
    TextView tvUserID, tvUsername;
    TextView editProfile;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_profile);
        tvUserID = (TextView)(findViewById(R.id.tvUserID));
        tvUsername = (TextView)(findViewById(R.id.tvUsername));
        editProfile = (TextView)(findViewById(R.id.tvProfileAdmin));

        Intent i3 = getIntent();
        String Username = i3.getStringExtra("Username");

        RequestQueue queue = Volley.newRequestQueue(this);
        String URL = "https://anaimcsci410.000webhostapp.com/getUser.php?Username=" +Username ;
        JsonArrayRequest request = new JsonArrayRequest(URL, new Response.Listener<JSONArray>() {


            @Override
            public void onResponse(JSONArray response) {
                try {
                    JSONObject row = response.getJSONObject(0);
                    int idUser = row.getInt("idUser");
                    String Username = row.getString("Username");
                    String Password = row.getString("Password");
                    String DOB = row.getString("DOB");

                    Users user = new Users(idUser , Username , Password, DOB);
                    tvUserID.setText(Integer.toString(user.getIdUser()));
                    tvUsername.setText(user.getUsername());


                } catch (Exception ex) {
                    Toast.makeText(Admin_Profile.this, "Error", Toast.LENGTH_LONG).show();

                }
            }
        }, null);

        queue.add(request);

        /*

        The Admin can change his username and password and dob on the system as he is a manager
        so no need to make an edit profile button .. but it is found in his profile and not clickable


        editProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                RequestQueue queue = Volley.newRequestQueue(Admin_Profile.this);
                String URL = "https://anaimcsci410.000webhostapp.com/getUser.php?Username=" +Username ;
                JsonArrayRequest request = new JsonArrayRequest(URL, new Response.Listener<JSONArray>() {


                    @Override
                    public void onResponse(JSONArray response) {
                        try {
                            JSONObject row = response.getJSONObject(0);
                            int idUser = row.getInt("idUser");
                            String Username = row.getString("Username");
                            String Password = row.getString("Password");
                            String DOB = row.getString("DOB");

                            Users user = new Users(idUser , Username , Password, DOB);
                            Intent Profile = new Intent(Admin_Profile.this , profile.class);
                            Profile.putExtra("Username", user.getUsername());
                            Profile.putExtra("Password", user.getPassword());
                            Profile.putExtra("DateOfBirth", user.getDOB());
                            Profile.putExtra("Id", user.getIdUser());
                            startActivity(Profile);
                            finish();


                        } catch (Exception ex) {
                            Toast.makeText(Admin_Profile.this, "Error", Toast.LENGTH_LONG).show();

                        }
                    }
                }, null);

                queue.add(request);
            }
        });
*/

    }


    public void remove(View view) {

        Intent r1 = new Intent(Admin_Profile.this , remove.class);
        startActivity(r1);
    }

    //public void editProfileAdmin(View view) {

       //     Intent Profile = new Intent(Admin_Profile.this , profile.class);
        //     Profile.putExtra("Username", )
           // startActivity(Profile);

     //   }

    public void LogoutAdmin(View view) {

        new AlertDialog.Builder(this)
                .setIcon(R.drawable.logout)
                .setTitle("Logging Out?")
                .setMessage("Are you sure you want to close this account?")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Intent Logout = new Intent(Admin_Profile.this , Log_Reg.class);
                        startActivity(Logout);
                        finish();
                    }

                })
                .setNegativeButton("No", null)
                .show();


    }

    public void notify(View view) {

        createNotificationChannel();
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "Abbas Naim")
                .setSmallIcon(R.drawable.notification)
                .setContentTitle("Budget Tracker Owner")
                .setContentText("Dear all users, soon the official app will be available on playstore. Be ready!!")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);

        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);

        // notificationId is a unique int for each notification that you must define
        notificationManager.notify(100, builder.build());
    }

    private void createNotificationChannel() {
        // Create the NotificationChannel, but only on API 26+ because
        // the NotificationChannel class is new and not in the support library
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Admin reminders";
            String description = "New announcements for users";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel("Abbas Naim", name, importance);
            channel.setDescription(description);
            // Register the channel with the system; you can't change the importance
            // or other notification behaviors after this
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }
}

