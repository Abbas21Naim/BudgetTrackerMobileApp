package com.example.seniorprojectbt;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public class _Register extends AppCompatActivity {


     int idUser = (int)(Math.random()*(100000));
     String id = Integer.toString(idUser);
    final Calendar DOB= Calendar.getInstance();
    EditText editText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

            final EditText etUsername = findViewById(R.id.etUsername);
            final EditText etPassword = findViewById(R.id.etPassword);
            final EditText etCPassword = findViewById(R.id.etCPassword);
            editText = (EditText) findViewById(R.id.etDOB);
            final Button btRegister = findViewById(R.id.btRegister);
            final ProgressBar pb1 = findViewById(R.id.pb1);
            pb1.setVisibility(View.INVISIBLE);


        final RequestQueue queue = Volley.newRequestQueue(this);

        DatePickerDialog.OnDateSetListener date =new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int day) {
                DOB.set(Calendar.YEAR, year);
                DOB.set(Calendar.MONTH,month);
                DOB.set(Calendar.DAY_OF_MONTH,day);
                updateLabel();
            }
        };
        editText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new DatePickerDialog(_Register.this,date,DOB.get(Calendar.YEAR),DOB.get(Calendar.MONTH),DOB.get(Calendar.DAY_OF_MONTH)).show();
            }
        });


        btRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String URL = "https://anaimcsci410.000webhostapp.com/register.php";

                pb1.setVisibility(View.VISIBLE);
                btRegister.setEnabled(false);

                StringRequest request =  new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Toast.makeText(_Register.this, response, Toast.LENGTH_SHORT).show();
                        pb1.setVisibility(View.INVISIBLE);
                        btRegister.setEnabled(true);
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(_Register.this, error.toString(), Toast.LENGTH_SHORT).show();
                        pb1.setVisibility(View.INVISIBLE);
                        btRegister.setEnabled(true);
                    }
                }) {
                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {
                        Map<String, String> params = new HashMap<>();
                        params.put("idUser", id);
                        params.put("username", etUsername.getText().toString());
                        params.put("password", etPassword.getText().toString());
                        params.put("cpassword", etCPassword.getText().toString());
                        params.put("dob", editText.getText().toString());
                        params.put("key", "keyKey123");

                        return params;
                    }

                };

                queue.add(request);
            }

        });
    }

    private void updateLabel(){
        String myFormat="yyyy-MM-dd";
        SimpleDateFormat dateFormat=new SimpleDateFormat(myFormat, Locale.US);
        editText.setText(dateFormat.format(DOB.getTime()));
    }

}


