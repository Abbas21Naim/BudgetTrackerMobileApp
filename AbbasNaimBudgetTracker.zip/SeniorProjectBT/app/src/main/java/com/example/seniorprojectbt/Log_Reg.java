package com.example.seniorprojectbt;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;



public class Log_Reg extends AppCompatActivity {
    EditText etUsername,etPass;

    String Username,password;
    String url = "https://anaimcsci410.000webhostapp.com/login.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_reg);

        etUsername = findViewById(R.id.etUsername);
        etPass = findViewById(R.id.etPass);
    }

    public void Login(View view) {

        if(etUsername.getText().toString().equals("")){
            Toast.makeText(this, "Enter your Username Please.", Toast.LENGTH_SHORT).show();
        }
        else if(etPass.getText().toString().equals("")){
            Toast.makeText(this, "Please enter a correct Password", Toast.LENGTH_SHORT).show();
        }
        else{


            Username = etUsername.getText().toString().trim();
            password = etPass.getText().toString().trim();


            StringRequest request = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {

                    if (response.equals("Success")) {

                        if (etUsername.getText().toString().trim().equals("Abbas")) {
                            Intent i3= new Intent(Log_Reg.this, Admin_Profile.class);
                            i3.putExtra("Username", etUsername.getText().toString());
                            startActivity(i3);

                        } else {
                            Intent i4= new Intent(Log_Reg.this, User_Profile.class);
                            i4.putExtra("Username", etUsername.getText().toString());
                            startActivity(i4);

                        }
                    } else if(response.equals("Failure")){
                        Toast.makeText(Log_Reg.this, "Invalid login Username Or Password", Toast.LENGTH_SHORT).show();

                        }
                    }
            },new Response.ErrorListener(){

                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(Log_Reg.this, error.toString(), Toast.LENGTH_SHORT).show();
                }
            }

            ){
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    Map<String,String> params = new HashMap<String, String>();
                    params.put("Username",Username);
                    params.put("Password",password);
                    return params;

                }
            };

            RequestQueue requestQueue = Volley.newRequestQueue(Log_Reg.this);
            requestQueue.add(request);




        }
    }


    public void register(View view) {
        Intent i1 = new Intent(Log_Reg.this, _Register.class);
        startActivity(i1);

        }
    }


