package com.example.seniorprojectbt;

public class Incomes {
    private int idIncome;
    private int UserId;
    private int IncAmount;
    private String IncDesc;
    private String IncDate;

    public Incomes(int idIncome, int userId, int incAmount, String incDesc, String incDate) {
        this.idIncome = idIncome;
        UserId = userId;
        IncAmount = incAmount;
        IncDesc = incDesc;
        IncDate = incDate;
    }

    @Override
    public String toString() {
        return  "idIncome=" + idIncome +
                ", IncAmount=" + IncAmount +
                ", IncDesc='" + IncDesc + '\'' +
                ", IncDate='" + IncDate + '\'' ;
    }
}
