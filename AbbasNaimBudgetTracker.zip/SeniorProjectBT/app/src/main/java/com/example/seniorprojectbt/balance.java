package com.example.seniorprojectbt;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

public class balance extends AppCompatActivity {

    TextView expenseAmount , incomeAmount , balanceAmount, balance, amount;
    Button Result;
    ProgressBar pb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {


        Intent B1 = getIntent();
        String str = B1.getStringExtra("Id");


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_balance);


        expenseAmount= (TextView)(findViewById(R.id.expensesamount));
        incomeAmount = (TextView)(findViewById(R.id.Incomesamount));
        balanceAmount = (TextView)(findViewById(R.id.balanceamount));
        balance = (TextView)(findViewById(R.id.balance));
        Result = (Button)(findViewById(R.id.Result));
        amount = (TextView)(findViewById(R.id.amount));
        pb = (ProgressBar)(findViewById(R.id.progress));


        amount.setVisibility(View.GONE);
        expenseAmount.setVisibility(View.GONE);
        incomeAmount.setVisibility(View.GONE);
        balanceAmount.setVisibility(View.GONE);
        balance.setVisibility(View.GONE);
        Result.setVisibility(View.GONE);
        pb.setVisibility(View.VISIBLE);


        RequestQueue queue = Volley.newRequestQueue(balance.this);
        String URL = "https://anaimcsci410.000webhostapp.com/SumExp.php?idUser=" + str;
        JsonArrayRequest request = new JsonArrayRequest(URL, new Response.Listener<JSONArray>() {




            @Override
            public void onResponse(JSONArray response) {
                try {
                    JSONObject row = response.getJSONObject(0);
                    String TotalExpense = row.getString("TotalExpense");
                    incomeAmount.setVisibility(View.VISIBLE);
                    balanceAmount.setVisibility(View.GONE);
                    amount.setVisibility(View.GONE);
                    balance.setVisibility(View.GONE);
                    expenseAmount.setVisibility(View.VISIBLE);
                    expenseAmount.setText(TotalExpense);
                    pb.setVisibility(View.INVISIBLE);

                } catch (Exception ex) {
                    Toast.makeText(balance.this, "Error", Toast.LENGTH_LONG).show();

                }
            }
        }, null);

        queue.add(request);




        RequestQueue queue2 = Volley.newRequestQueue(balance.this);
        String URL2 = "https://anaimcsci410.000webhostapp.com/SumInc.php?idUser=" + str;
        JsonArrayRequest request2 = new JsonArrayRequest(URL2, new Response.Listener<JSONArray>() {


            @Override
            public void onResponse(JSONArray response) {
                try {
                    JSONObject row = response.getJSONObject(0);
                    String TotalIncome = row.getString("TotalIncome");
                    incomeAmount.setVisibility(View.VISIBLE);
                    balanceAmount.setVisibility(View.GONE);
                    amount.setVisibility(View.GONE);
                    balance.setVisibility(View.GONE);
                    expenseAmount.setVisibility(View.VISIBLE);
                    incomeAmount.setText(TotalIncome);
                    pb.setVisibility(View.INVISIBLE);


                } catch (Exception ex) {
                    Toast.makeText(balance.this, "Error", Toast.LENGTH_LONG).show();

                }
            }
        }, null);

        queue2.add(request2);

        Result.setVisibility(View.VISIBLE);
        Result.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View v) {


                pb.setVisibility(View.VISIBLE);
                incomeAmount.setVisibility(View.VISIBLE);
                Result.setVisibility(View.VISIBLE);
                expenseAmount.setVisibility(View.VISIBLE);

                int wallet1 = Integer.parseInt(incomeAmount.getText().toString()) - Integer.parseInt(expenseAmount.getText().toString());
                String wallet2 = Integer.toString(wallet1);
                balanceAmount.setText(wallet2);
                balance.setVisibility(View.VISIBLE);
                amount.setVisibility(View.VISIBLE);
                balanceAmount.setVisibility(View.VISIBLE);
                pb.setVisibility(View.GONE);

            }
        });

        }
}
