package com.example.seniorprojectbt;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class remove extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_remove);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        final Button remove = findViewById(R.id.btnRemove);
        final EditText id = findViewById(R.id.etidUser);
        final ProgressBar pb = findViewById(R.id.progressBar);
        pb.setVisibility(View.INVISIBLE);
        final RequestQueue queue = Volley.newRequestQueue(this);

        remove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String URL = "https://anaimcsci410.000webhostapp.com/removeUser.php?idUser=" + id.getText().toString();
                pb.setVisibility(View.VISIBLE);
                remove.setEnabled(false);
                StringRequest request = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Toast.makeText(remove.this, response, Toast.LENGTH_SHORT).show();
                        pb.setVisibility(View.INVISIBLE);
                        remove.setEnabled(true);
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(remove.this, error.toString(), Toast.LENGTH_SHORT).show();
                        pb.setVisibility(View.INVISIBLE);
                        remove.setEnabled(true);
                    }
                }) {

                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {
                        Map<String, String> params = new HashMap<>();
                        params.put("idUser", id.getText().toString());
                        return params;
                    }
                };
                queue.add(request);
            }


        });

    }
}