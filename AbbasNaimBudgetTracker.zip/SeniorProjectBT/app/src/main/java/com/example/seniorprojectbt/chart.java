package com.example.seniorprojectbt;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class chart extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chart);
    }
}


//no Library accessed for this idea
//and the only one isn't working in xml

//repositories {
// maven { url "https://jitpack.io" }
//}
//
//dependencies {
// compile 'com.github.PhilJay:MPAndroidChart:v2.2.4'
//}

//this is the library to implement and the maven repository concerning the barChart