<?php
 $idUser= addslashes(strip_tags($_POST['ID']));
 $Exp = addslashes(strip_tags($_POST['idExp']));
 $Amount = addslashes(strip_tags($_POST['AmountExp']));
 $DateExp = addslashes(strip_tags($_POST['DateExp']));
 $DescExp = addslashes(strip_tags($_POST['DescExp']));

 $idExp = intval($Exp);
 $AmountExp = intval($Amount);
 
 if (trim($idUser) == "" or trim($Exp) == "" or trim($Amount) == "" or trim($DateExp) == "" or trim($DescExp) == "" ){
    die("Access denied. All field should be filled.");
    
 }
 
 
    
    if ( strlen($DescExp) > 255 ){
        die("The description should be less than 255 characters.");
    
 }
    
 	$conn=mysqli_connect("localhost","id18322645_senioran","Yzo9m>lk^r*JuYPz","id18322645_budgettracker");
 	
 	
//check cnx 

if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }

   $query          =  "INSERT INTO Expenses values ('$idExp' ,'$idUser','$AmountExp','$DescExp', '$DateExp')";


mysqli_query($conn,$query);

echo "Expense added to your balance succefully.";


   mysqli_close($conn);

?>