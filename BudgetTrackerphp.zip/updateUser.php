<?php
 $oldusername= addslashes(strip_tags($_POST['oldUsername']));
 $newusername = addslashes(strip_tags($_POST['newUsername']));
 
 if($newusername == $oldusername){
    if (trim($newusername) == ""){
        die("Access denied. Field empty!!");
     } die("Your new username is the same of the old one.");}
    
 	$conn=mysqli_connect("localhost","id18322645_senioran","Yzo9m>lk^r*JuYPz","id18322645_budgettracker");
 	
 	
//check cnx 

if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
   
     $query    = "SELECT Username FROM users WHERE Username='$oldusername'";
     $result   = mysqli_query($conn, $query);
   if ($row = mysqli_fetch_array($result)) {
       $query          = "UPDATE users SET Username='$newusername' WHERE Username='$oldusername'";
   
 mysqli_query($conn,$query) or
    die ("Error");

echo "Changes Applied succefully";
   } 
   else echo "Session timeout login again.";
 
    mysqli_free_result($result);
    mysqli_close($conn);

?>