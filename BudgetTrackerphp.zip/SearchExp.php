<?php

    $ExpDate = $_GET['DateExp'];
	$idUser = $_GET['idUser'];
	
	
	$id = intval($idUser);

$conn=mysqli_connect("localhost","id18322645_senioran","Yzo9m>lk^r*JuYPz","id18322645_budgettracker");

// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  
  }
  
  $sql = "SELECT * FROM Expenses WHERE ExpDate= '$ExpDate' AND UserId='$id'";
if ($result = mysqli_query($conn,$sql))
  {
   $emparray = array();
   while($row =mysqli_fetch_assoc($result))
       $emparray[] = $row;

  echo(json_encode($emparray));
  // Free result set
  mysqli_free_result($result);
  mysqli_close($conn);
} 
?>