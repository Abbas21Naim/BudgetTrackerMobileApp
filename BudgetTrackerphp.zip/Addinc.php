<?php
 $idUser= addslashes(strip_tags($_POST['ID']));
 $Inc = addslashes(strip_tags($_POST['idInc']));
 $Amount = addslashes(strip_tags($_POST['AmountInc']));
 $DateInc = addslashes(strip_tags($_POST['DateInc']));
 $DescInc = addslashes(strip_tags($_POST['DescInc']));

 $idInc = intval($Inc);
 $AmountInc = intval($Amount);
 
 if (trim($idUser) == "" or trim($Inc) == "" or trim($Amount) == "" or trim($DateInc) == "" or trim($DescInc) == "" ){
    die("Access denied. All field should be filled.");
    
 }
 
 
    
    if ( strlen($DescInc) > 255 ){
        die("The description should be less than 255 characters.");
    
 }
    
 	$conn=mysqli_connect("localhost","id18322645_senioran","Yzo9m>lk^r*JuYPz","id18322645_budgettracker");
 	
 	
//check cnx 

if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }

   $query          =  "INSERT INTO Incomes values ('$idInc' ,'$idUser','$AmountInc','$DescInc', '$DateInc')";


mysqli_query($conn,$query) or
    die ("You have already an income with this id.");

echo "Income added to your balance succefully.";


   mysqli_close($conn);

?>