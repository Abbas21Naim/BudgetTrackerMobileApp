<?php
 $oldusername= addslashes(strip_tags($_POST['oldUsername']));
 $newpassword = addslashes(strip_tags($_POST['newPassword']));
 $cnewpassword = addslashes(strip_tags($_POST['confirmPass']));
 
 
 if($newpassword == "" && $cnewpassword == "" or $newpassword != $cnewpassword){
     
     die("Passwords must match and fields should not be empty.");
     
 }
 
 
    
 	$conn=mysqli_connect("localhost","id18322645_senioran","Yzo9m>lk^r*JuYPz","id18322645_budgettracker");
 	
 	
//check cnx 

if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
   
     
     $query    = "SELECT Username FROM users WHERE Username='$oldusername'";
     $result   = mysqli_query($conn, $query);
   if ($row = mysqli_fetch_array($result)) {
       $query          = "UPDATE users SET Password='$newpassword' WHERE Username='$oldusername'";
   
 mysqli_query($conn,$query) or
    die ("Error");

echo "Changes Applied succefully";
   } 
  else echo "Session timeout login again.";
 
    mysqli_free_result($result);
    mysqli_close($conn);

?>