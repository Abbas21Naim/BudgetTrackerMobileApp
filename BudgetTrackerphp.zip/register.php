<?php
 $idUser= addslashes(strip_tags($_POST['idUser']));
 $username = addslashes(strip_tags($_POST['username']));
 $password = addslashes(strip_tags($_POST['password']));
 $cpassword = addslashes(strip_tags($_POST['cpassword']));
 $dob = addslashes(strip_tags($_POST['dob']));
 $key = addslashes(strip_tags($_POST['key']));
 

 
 
 if ($key != "keyKey123" or trim($username) == "" or $password != $cpassword){
    die("Access denied. Check your username or password please!!");
    
 }
    
 	$conn=mysqli_connect("localhost","id18322645_senioran","Yzo9m>lk^r*JuYPz","id18322645_budgettracker");
 	
 	
//check cnx 

if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
   
   $sql = "INSERT INTO users values ('$idUser' ,'$username','$password','$dob')";
   
   
 
 mysqli_query($conn,$sql) or
    die ("Registration Failed Try again.");

echo "You are registered succefully";
   
mysqli_close($conn);

?>