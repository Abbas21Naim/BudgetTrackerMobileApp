<?php
	$username = $_POST['Username'];
    $password = $_POST['Password'];

$conn=mysqli_connect("localhost","id18322645_senioran","Yzo9m>lk^r*JuYPz","id18322645_budgettracker");

// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }

$sql = "SELECT * FROM users WHERE Username = '$username' AND Password = '$password'";
$result = mysqli_query($conn,$sql);

if($result->num_rows > 0){
			echo "Success" ;
		}else 
		echo "Failure"

?>