<?php
if (!isset($_POST['idUser']))
    die('Failure.');
    $con=mysqli_connect("localhost","id18322645_senioran","Yzo9m>lk^r*JuYPz","id18322645_budgettracker");
    $id =($_GET['idUser']);
    
    
    if (trim($id) == ""){
    die("Access denied. Please fill up the required field!!");
    
 }
    
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
  
$sql = "SELECT idUser FROM users WHERE idUser='$id'" ;
$result= mysqli_query($con,$sql);
if(mysqli_num_rows($result)>0)
{
    $sql2= "Delete from users where idUser ='$id'";
    $result= mysqli_query($con,$sql2);
    echo "User deleted Successfully";
}else 
  {
      echo "User not found.";
 }

mysqli_close($con);


?>